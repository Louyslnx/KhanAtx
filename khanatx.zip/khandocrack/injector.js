(function() {
    function injectScriptFile() {
        const script = document.createElement("script");
        script.setAttribute('type', 'text/javascript');
        script.src = chrome.runtime.getURL("inject.js");
        script.onload = function() {
            this.remove(); // Remove the script element after loading
        };
        (document.head || document.documentElement).appendChild(script);
    }

    // Verificar se o documento já está carregado
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', injectScriptFile);
    } else {
        injectScriptFile();
    }
})();