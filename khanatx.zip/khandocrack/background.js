chrome.runtime.onInstalled.addListener(() => {
    console.log('KhanAtx Extension Installed');
  });