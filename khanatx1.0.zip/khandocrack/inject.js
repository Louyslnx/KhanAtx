
const APP = {
    ver: "1.0",
    user: { id: 0 },
    cfg: {
        mod: true,
        auto: false
    }
};

class UI {
    static init() {
        const menu = document.createElement('div');
        
        Object.assign(menu.style, {
            position: 'fixed',
            top: '10px',
            right: '15px',
            width: '180px',
            background: 'linear-gradient(145deg, #1a1a1a, #111)',
            borderRadius: '12px',
            display: 'flex',
            flexDirection: 'column',
            padding: '12px',
            zIndex: '9999',
            boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
            border: '1px solid #333'
        });
        
        menu.innerHTML = `
            <style>
                .atx-header {
                    color: #fff;
                    font-size: 18px;
                    font-weight: bold;
                    text-align: center;
                    margin-bottom: 10px;
                    padding-bottom: 10px;
                    border-bottom: 1px solid #333;
                }
                .atx-version {
                    color: #666;
                    font-size: 12px;
                    font-weight: normal;
                }
                .atx-opt {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    color: #fff;
                    padding: 8px;
                    margin: 3px 0;
                }
                .switch {
                    position: relative;
                    display: inline-block;
                    width: 44px;
                    height: 22px;
                }
                .switch input {
                    opacity: 0;
                    width: 0;
                    height: 0;
                }
                .slider {
                    position: absolute;
                    cursor: pointer;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-color: #333;
                    transition: .4s;
                    border-radius: 22px;
                }
                .slider:before {
                    position: absolute;
                    content: "";
                    height: 18px;
                    width: 18px;
                    left: 2px;
                    bottom: 2px;
                    background-color: white;
                    transition: .4s;
                    border-radius: 50%;
                }
                input:checked + .slider {
                    background: linear-gradient(145deg, #6200ea, #7c4dff);
                }
                input:checked + .slider:before {
                    transform: translateX(22px);
                }
                .atx-credit {
                    color: #666;
                    font-size: 11px;
                    text-align: center;
                    margin-top: 10px;
                    padding-top: 10px;
                    border-top: 1px solid #333;
                }
            </style>
            <div class="atx-header">
                ATX <span class="atx-version">${APP.ver}</span>
            </div>
            <div class="atx-opt">
                <span>Auto Complete</span>
                <label class="switch">
                    <input type="checkbox" id="autoCheck">
                    <span class="slider"></span>
                </label>
            </div>
            <div class="atx-credit">by LouysAtx</div>
        `;

        document.body.appendChild(menu);

        document.getElementById('autoCheck').onchange = e => {
            APP.cfg.auto = e.target.checked;
        };
    }
}

class Core {
    static init() {
        this.setupMod();
        this.setupAuto();
    }

    static setupMod() {
        const msgs = ["⚡ ATX", "📝 LouysAtx", "✨ ATXHOST"];
        const origFetch = window.fetch;
        
        window.fetch = async function(input, init) {
            const resp = await origFetch.apply(this, arguments);
            const clone = resp.clone();
            
            try {
                const txt = await clone.text();
                let data = JSON.parse(txt);
                
                if (data?.data?.assessmentItem?.item?.itemData) {
                    let item = JSON.parse(data.data.assessmentItem.item.itemData);
                    
                    if (item.question.content[0] === item.question.content[0].toUpperCase()) {
                        item.answerArea = { calculator: false };
                        item.question.content = msgs[Math.floor(Math.random() * msgs.length)] + `[[☃ radio 1]]`;
                        item.question.widgets = {
                            "radio 1": {
                                options: {
                                    choices: [
                                        { content: "✓", correct: true },
                                        { content: "×", correct: false }
                                    ]
                                }
                            }
                        };
                        data.data.assessmentItem.item.itemData = JSON.stringify(item);
                        return new Response(JSON.stringify(data), {
                            status: resp.status,
                            statusText: resp.statusText,
                            headers: resp.headers
                        });
                    }
                }
            } catch (e) {}
            return resp;
        };
    }

    static async setupAuto() {
        const baseClasses = ["_1tuo6xk", "_ssxvf9l", "_1f0fvyce", "_rz7ls7u", "_1yok8f4", "_1e5cuk2a"];
        while (true) {
            if (APP.cfg.auto) {
                baseClasses.forEach(className => {
                    const element = document.getElementsByClassName(className)[0];
                    if (element) {
                        element.click();
                    }
                });
            }
            await new Promise(r => setTimeout(r, 750)); 
        }
    }
}


    UI.init();
    Core.init();
